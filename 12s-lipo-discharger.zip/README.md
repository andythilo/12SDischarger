# 12S LiPo Discharger (10A)

This project is a DIY 12S LiPo battery discharger capable of maintaining a constant 10A discharge current.

## Features
- Supports up to 12S (50.4V) LiPo packs
- Constant current control using power MOSFETs and op-amp feedback
- Arduino Nano for monitoring voltage and temperature
- Automatic fan control based on heatsink temperature
- Cutoff at 3.8V per cell (45.6V total)

## Contents
- KiCad schematic and PCB layout
- Arduino firmware
- Bill of Materials (BOM)

## Author
Generated with assistance from ChatGPT
